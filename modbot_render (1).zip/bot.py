import discord
from discord import app_commands
from datetime import datetime, timezone
import asyncio, re, random, json, os
import datetime as dt

import os
from flask import Flask
from threading import Thread

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running!"

def run_flask():
    app.run(host='0.0.0.0', port=8080)

Thread(target=run_flask, daemon=True).start()

TOKEN = "MTQ2NTQxMzk0NTgxMTY2NTE2Nw.GilNm_.59ZpcFoOHgJJ195daXzeM37L4UolAm8B7d-tzQ"

MOD_LOG_CHANNEL    = 1480116267817111675
SERVER_LOG_CHANNEL = 1480116313962844202
SPAM_LOG_CHANNEL   = 1480116142247776357
MOD_ROLE_ID        = 1472187516487471244

ALLOWED_LINK_ROLES = {MOD_ROLE_ID}
LINK_PATTERN = re.compile(r"https?://|discord\.gg/|www\.", re.IGNORECASE)
spam_tracker = {}
SPAM_LIMIT   = 5
SPAM_WINDOW  = 5
WARNS_FILE   = "warns.json"

def load_warns():
    if os.path.exists(WARNS_FILE):
        with open(WARNS_FILE) as f: return json.load(f)
    return {}

def save_warns(data):
    with open(WARNS_FILE, "w") as f: json.dump(data, f)

warn_data = load_warns()

intents = discord.Intents.all()
client  = discord.Client(intents=intents)
tree    = app_commands.CommandTree(client)


# ─── HELPERS ──────────────────────────────────────

def is_mod(interaction: discord.Interaction) -> bool:
    return any(r.id == MOD_ROLE_ID for r in interaction.user.roles)

async def mod_check(interaction: discord.Interaction) -> bool:
    if is_mod(interaction): return True
    try: await interaction.user.send("❌ אין לך הרשאות להשתמש בפקודה הזו!")
    except: pass
    await interaction.response.send_message("❌ אין לך הרשאות!", ephemeral=True)
    return False

async def send_log(channel_id: int, embed: discord.Embed):
    ch = client.get_channel(channel_id)
    if ch: await ch.send(embed=embed)

def mod_embed(title, color, **fields):
    e = discord.Embed(title=title, color=color, timestamp=datetime.now(timezone.utc))
    for k, v in fields.items():
        e.add_field(name=k, value=str(v), inline=False)
    return e


# ─── EVENTS ───────────────────────────────────────

@client.event
async def on_ready():
    await tree.sync()
    print(f"✅ בוט מחובר: {client.user}")
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="השרת 🛡️"))

@client.event
async def on_member_join(member: discord.Member):
    e = mod_embed("📥 משתמש הצטרף", discord.Color.green(), **{
        "משתמש": f"{member.mention} ({member.name})", "ID": str(member.id),
        "חשבון נוצר": f"<t:{int(member.created_at.timestamp())}:R>",
        "משתמשים": str(member.guild.member_count)})
    e.set_thumbnail(url=member.display_avatar.url)
    await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_member_remove(member: discord.Member):
    e = mod_embed("📤 משתמש עזב", discord.Color.red(), **{
        "משתמש": member.name, "ID": str(member.id),
        "משתמשים": str(member.guild.member_count)})
    e.set_thumbnail(url=member.display_avatar.url)
    await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_member_update(before: discord.Member, after: discord.Member):
    if before.nick != after.nick:
        e = mod_embed("✏️ שינוי כינוי", discord.Color.blurple(), **{
            "משתמש": after.mention, "לפני": before.nick or before.name, "אחרי": after.nick or after.name})
        await send_log(SERVER_LOG_CHANNEL, e)
    added   = [r for r in after.roles  if r not in before.roles]
    removed = [r for r in before.roles if r not in after.roles]
    if added:
        e = mod_embed("➕ רול נוסף", discord.Color.green(), **{"משתמש": after.mention, "רול": added[0].mention})
        await send_log(SERVER_LOG_CHANNEL, e)
    if removed:
        e = mod_embed("➖ רול הוסר", discord.Color.orange(), **{"משתמש": after.mention, "רול": removed[0].mention})
        await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_message_delete(message: discord.Message):
    if message.author.bot: return
    e = mod_embed("🗑️ הודעה נמחקה", discord.Color.orange(), **{
        "משתמש": str(message.author), "ערוץ": f"<#{message.channel.id}>",
        "תוכן": message.content[:1000] or "*(ריק)*"})
    await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_message_edit(before: discord.Message, after: discord.Message):
    if before.author.bot or before.content == after.content: return
    e = mod_embed("✏️ הודעה עודכנה", discord.Color.blurple(), **{
        "משתמש": str(before.author), "ערוץ": f"<#{before.channel.id}>",
        "לפני": before.content[:500] or "*(ריק)*", "אחרי": after.content[:500] or "*(ריק)*"})
    await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_voice_state_update(member, before, after):
    if before.channel != after.channel:
        if after.channel:
            e = mod_embed("🔊 כניסה לוויס", discord.Color.green(), **{"משתמש": member.mention, "ערוץ": after.channel.name})
            await send_log(SERVER_LOG_CHANNEL, e)
        elif before.channel:
            e = mod_embed("🔇 יציאה מוויס", discord.Color.red(), **{"משתמש": member.mention, "ערוץ": before.channel.name})
            await send_log(SERVER_LOG_CHANNEL, e)

@client.event
async def on_message(message: discord.Message):
    if message.author.bot: return
    uid = message.author.id
    now = datetime.now(timezone.utc).timestamp()
    has_allowed = any(r.id in ALLOWED_LINK_ROLES for r in message.author.roles)
    if not has_allowed and LINK_PATTERN.search(message.content):
        await message.delete()
        try: await message.author.send(f"❌ אסור לשלוח לינקים בשרת **{message.guild.name}**!")
        except: pass
        e = mod_embed("🔗 לינק חסום", discord.Color.red(), **{
            "משתמש": message.author.mention, "ערוץ": f"<#{message.channel.id}>", "תוכן": message.content[:500]})
        await send_log(SPAM_LOG_CHANNEL, e)
        return
    if uid not in spam_tracker: spam_tracker[uid] = []
    spam_tracker[uid] = [t for t in spam_tracker[uid] if now - t < SPAM_WINDOW]
    spam_tracker[uid].append(now)
    if len(spam_tracker[uid]) >= SPAM_LIMIT:
        spam_tracker[uid] = []
        await message.channel.purge(limit=SPAM_LIMIT, check=lambda m: m.author.id == uid)
        try:
            await message.author.timeout(discord.utils.utcnow() + dt.timedelta(minutes=5))
            await message.author.send(f"⚠️ הושתקת בשרת **{message.guild.name}** ל-5 דקות בגלל ספאם!")
        except: pass
        await message.channel.send(f"{message.author.mention} ⚠️ זוהה ספאם! הושתק ל-5 דקות.", delete_after=8)
        e = mod_embed("🚨 ספאם", discord.Color.red(), **{
            "משתמש": message.author.mention, "ערוץ": f"<#{message.channel.id}>", "פעולה": "מיוט 5 דקות"})
        await send_log(SPAM_LOG_CHANNEL, e)


# ─── SLASH COMMANDS ───────────────────────────────

@tree.command(name="ban", description="באן למשתמש")
@app_commands.describe(member="משתמש", reason="סיבה")
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    try: await member.send(f"🔨 עוּבָּנְת מהשרת **{interaction.guild.name}**\nסיבה: {reason}")
    except: pass
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 {member.mention} עוּבָּן.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔨 BAN", discord.Color.red(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "סיבה": reason}))

@tree.command(name="unban", description="הסרת באן")
@app_commands.describe(user_id="ID של המשתמש")
async def unban(interaction: discord.Interaction, user_id: str):
    if not await mod_check(interaction): return
    user = await client.fetch_user(int(user_id))
    await interaction.guild.unban(user)
    await interaction.response.send_message(f"✅ {user} עוּבָּן הוסר.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("✅ UNBAN", discord.Color.green(), **{"משתמש": f"{user} ({user_id})", "מודרטור": str(interaction.user)}))

@tree.command(name="softban", description="סופטבאן — מוחק הודעות ומייד מבטל")
@app_commands.describe(member="משתמש", reason="סיבה")
async def softban(interaction: discord.Interaction, member: discord.Member, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    try: await member.send(f"🔨 סופטבאן מהשרת **{interaction.guild.name}**\nסיבה: {reason}")
    except: pass
    await member.ban(reason=reason, delete_message_days=7)
    await interaction.guild.unban(member)
    await interaction.response.send_message(f"✅ {member.mention} סופטבאן.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔨 SOFTBAN", discord.Color.orange(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "סיבה": reason}))

@tree.command(name="tempban", description="באן זמני")
@app_commands.describe(member="משתמש", minutes="דקות", reason="סיבה")
async def tempban(interaction: discord.Interaction, member: discord.Member, minutes: int = 60, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    try: await member.send(f"🔨 עוּבָּנְת זמנית מהשרת **{interaction.guild.name}** ל-{minutes} דקות\nסיבה: {reason}")
    except: pass
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 {member.mention} עוּבָּן ל-{minutes} דקות.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔨 TEMPBAN", discord.Color.red(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "זמן": f"{minutes} דקות", "סיבה": reason}))
    await asyncio.sleep(minutes * 60)
    try: await interaction.guild.unban(member)
    except: pass

@tree.command(name="kick", description="קיק למשתמש")
@app_commands.describe(member="משתמש", reason="סיבה")
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    try: await member.send(f"👢 קוּבַּלְת מהשרת **{interaction.guild.name}**\nסיבה: {reason}")
    except: pass
    await member.kick(reason=reason)
    await interaction.response.send_message(f"👢 {member.mention} קוּבַּל.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("👢 KICK", discord.Color.orange(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "סיבה": reason}))

@tree.command(name="mute", description="השתקת משתמש")
@app_commands.describe(member="משתמש", minutes="דקות", reason="סיבה")
async def mute(interaction: discord.Interaction, member: discord.Member, minutes: int = 10, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    until = discord.utils.utcnow() + dt.timedelta(minutes=minutes)
    await member.timeout(until, reason=reason)
    try: await member.send(f"🔇 הושתקת בשרת **{interaction.guild.name}** ל-{minutes} דקות\nסיבה: {reason}")
    except: pass
    await interaction.response.send_message(f"🔇 {member.mention} הושתק ל-{minutes} דקות.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔇 MUTE", discord.Color.dark_gray(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "זמן": f"{minutes} דקות", "סיבה": reason}))

@tree.command(name="unmute", description="ביטול השתקה")
@app_commands.describe(member="משתמש")
async def unmute(interaction: discord.Interaction, member: discord.Member):
    if not await mod_check(interaction): return
    await member.timeout(None)
    try: await member.send(f"🔊 השתקתך בשרת **{interaction.guild.name}** הוסרה!")
    except: pass
    await interaction.response.send_message(f"🔊 {member.mention} בוטל השתקה.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔊 UNMUTE", discord.Color.green(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user)}))

@tree.command(name="warn", description="אזהרה למשתמש")
@app_commands.describe(member="משתמש", reason="סיבה")
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str = "לא צוין"):
    if not await mod_check(interaction): return
    uid = str(member.id)
    if uid not in warn_data: warn_data[uid] = []
    warn_data[uid].append({"reason": reason, "by": str(interaction.user), "time": str(datetime.now(timezone.utc))})
    save_warns(warn_data)
    count = len(warn_data[uid])
    try: await member.send(f"⚠️ קיבלת אזהרה #{count} בשרת **{interaction.guild.name}**\nסיבה: {reason}")
    except: pass
    await interaction.response.send_message(f"⚠️ {member.mention} קיבל אזהרה #{count}.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("⚠️ WARN", discord.Color.yellow(), **{"משתמש": f"{member} ({member.id})", "מודרטור": str(interaction.user), "סיבה": reason, "סה\"כ": str(count)}))
    if count == 3:
        await member.timeout(discord.utils.utcnow() + dt.timedelta(hours=1))
        try: await member.send("🔇 הושתקת שעה אחת (3 אזהרות)")
        except: pass
    elif count >= 5:
        try: await member.send(f"🔨 עוּבָּנְת (5 אזהרות)")
        except: pass
        await member.ban(reason="5 אזהרות")

@tree.command(name="warnings", description="הצג אזהרות של משתמש")
@app_commands.describe(member="משתמש")
async def warnings(interaction: discord.Interaction, member: discord.Member):
    uid = str(member.id)
    warns = warn_data.get(uid, [])
    if not warns:
        await interaction.response.send_message(f"✅ ל-{member.mention} אין אזהרות.", ephemeral=True); return
    e = discord.Embed(title=f"⚠️ אזהרות של {member.name}", color=discord.Color.yellow())
    for i, w in enumerate(warns, 1):
        e.add_field(name=f"#{i}", value=f"סיבה: {w['reason']}\nמודרטור: {w['by']}", inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)

@tree.command(name="clearwarns", description="מחיקת אזהרות")
@app_commands.describe(member="משתמש")
async def clearwarns(interaction: discord.Interaction, member: discord.Member):
    if not await mod_check(interaction): return
    warn_data[str(member.id)] = []
    save_warns(warn_data)
    await interaction.response.send_message(f"✅ אזהרות של {member.mention} נמחקו.")

@tree.command(name="clear", description="מחיקת הודעות")
@app_commands.describe(amount="כמות")
async def clear(interaction: discord.Interaction, amount: int = 10):
    if not await mod_check(interaction): return
    await interaction.channel.purge(limit=amount)
    await interaction.response.send_message(f"🗑️ נמחקו {amount} הודעות.", ephemeral=True)
    await send_log(MOD_LOG_CHANNEL, mod_embed("🗑️ CLEAR", discord.Color.blurple(), **{"ערוץ": f"<#{interaction.channel.id}>", "כמות": str(amount), "מודרטור": str(interaction.user)}))

@tree.command(name="purge", description="מחיקת הודעות של משתמש ספציפי")
@app_commands.describe(member="משתמש", amount="כמות")
async def purge(interaction: discord.Interaction, member: discord.Member, amount: int = 20):
    if not await mod_check(interaction): return
    deleted = await interaction.channel.purge(limit=amount, check=lambda m: m.author == member)
    await interaction.response.send_message(f"🗑️ נמחקו {len(deleted)} הודעות של {member.mention}.", ephemeral=True)

@tree.command(name="slowmode", description="הגדרת slowmode")
@app_commands.describe(seconds="שניות (0 לביטול)")
async def slowmode(interaction: discord.Interaction, seconds: int = 0):
    if not await mod_check(interaction): return
    await interaction.channel.edit(slowmode_delay=seconds)
    await interaction.response.send_message(f"🐢 Slowmode: {seconds} שניות.")

@tree.command(name="lock", description="נעילת ערוץ")
async def lock(interaction: discord.Interaction):
    if not await mod_check(interaction): return
    await interaction.channel.set_permissions(interaction.guild.default_role, send_messages=False)
    await interaction.response.send_message("🔒 הערוץ ננעל.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔒 LOCK", discord.Color.red(), **{"ערוץ": f"<#{interaction.channel.id}>", "מודרטור": str(interaction.user)}))

@tree.command(name="unlock", description="פתיחת ערוץ")
async def unlock(interaction: discord.Interaction):
    if not await mod_check(interaction): return
    await interaction.channel.set_permissions(interaction.guild.default_role, send_messages=True)
    await interaction.response.send_message("🔓 הערוץ נפתח.")
    await send_log(MOD_LOG_CHANNEL, mod_embed("🔓 UNLOCK", discord.Color.green(), **{"ערוץ": f"<#{interaction.channel.id}>", "מודרטור": str(interaction.user)}))

@tree.command(name="nick", description="שינוי כינוי")
@app_commands.describe(member="משתמש", name="שם חדש (ריק למחיקה)")
async def nick(interaction: discord.Interaction, member: discord.Member, name: str = ""):
    if not await mod_check(interaction): return
    await member.edit(nick=name or None)
    await interaction.response.send_message(f"✅ כינוי עודכן.")

@tree.command(name="role", description="הוספה/הסרה של רול")
@app_commands.describe(member="משתמש", role="רול")
async def role_cmd(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    if not await mod_check(interaction): return
    if role in member.roles:
        await member.remove_roles(role)
        await interaction.response.send_message(f"➖ {role.mention} הוסר מ-{member.mention}.")
    else:
        await member.add_roles(role)
        await interaction.response.send_message(f"➕ {role.mention} נוסף ל-{member.mention}.")

@tree.command(name="move", description="העברת משתמש לוויס אחר")
@app_commands.describe(member="משתמש", channel="ערוץ קול")
async def move(interaction: discord.Interaction, member: discord.Member, channel: discord.VoiceChannel):
    if not await mod_check(interaction): return
    await member.move_to(channel)
    await interaction.response.send_message(f"✅ {member.mention} הועבר ל-{channel.name}.")

@tree.command(name="vckick", description="הוצאת משתמש מוויס")
@app_commands.describe(member="משתמש")
async def vckick(interaction: discord.Interaction, member: discord.Member):
    if not await mod_check(interaction): return
    await member.move_to(None)
    await interaction.response.send_message(f"✅ {member.mention} הוצא מהוויס.")

@tree.command(name="say", description="הבוט ישלח הודעה")
@app_commands.describe(text="טקסט")
async def say(interaction: discord.Interaction, text: str):
    if not await mod_check(interaction): return
    await interaction.response.send_message("✅ נשלח!", ephemeral=True)
    await interaction.channel.send(text)

@tree.command(name="embed", description="הבוט ישלח embed")
@app_commands.describe(text="טקסט")
async def embed_cmd(interaction: discord.Interaction, text: str):
    if not await mod_check(interaction): return
    await interaction.response.send_message("✅ נשלח!", ephemeral=True)
    e = discord.Embed(description=text, color=discord.Color.blurple())
    await interaction.channel.send(embed=e)

@tree.command(name="poll", description="יצירת סקר")
@app_commands.describe(question="שאלה")
async def poll(interaction: discord.Interaction, question: str):
    e = discord.Embed(title="📊 סקר", description=question, color=discord.Color.blurple())
    e.set_footer(text=f"סקר של {interaction.user.display_name}")
    await interaction.response.send_message(embed=e)
    msg = await interaction.original_response()
    await msg.add_reaction("👍")
    await msg.add_reaction("👎")
    await msg.add_reaction("🤷")

@tree.command(name="giveaway", description="הגרלה")
@app_commands.describe(minutes="דקות", prize="פרס")
async def giveaway(interaction: discord.Interaction, minutes: int, prize: str):
    if not await mod_check(interaction): return
    e = discord.Embed(title="🎉 הגרלה!", color=discord.Color.gold())
    e.description = f"**{prize}**\n\nהגיב 🎉 להשתתף!\nמסתיים בעוד {minutes} דקות"
    e.set_footer(text=f"מארגן: {interaction.user.display_name}")
    await interaction.response.send_message(embed=e)
    msg = await interaction.original_response()
    await msg.add_reaction("🎉")
    await asyncio.sleep(minutes * 60)
    msg = await interaction.channel.fetch_message(msg.id)
    users = [u async for u in msg.reactions[0].users() if not u.bot]
    if not users:
        await interaction.channel.send("😢 אף אחד לא השתתף."); return
    winner = __import__("random").choice(users)
    await interaction.channel.send(f"🎉 המנצח ב-**{prize}**: {winner.mention}! מזל טוב!")

@tree.command(name="userinfo", description="מידע על משתמש")
@app_commands.describe(member="משתמש")
async def userinfo(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    roles = [r.mention for r in member.roles[1:]]
    e = discord.Embed(title=f"👤 {member.name}", color=member.color)
    e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="ID", value=str(member.id))
    e.add_field(name="כינוי", value=member.nick or "אין")
    e.add_field(name="הצטרף", value=f"<t:{int(member.joined_at.timestamp())}:R>")
    e.add_field(name="חשבון נוצר", value=f"<t:{int(member.created_at.timestamp())}:R>")
    e.add_field(name=f"רולים ({len(roles)})", value=" ".join(roles[:10]) or "אין", inline=False)
    warns = warn_data.get(str(member.id), [])
    e.add_field(name="⚠️ אזהרות", value=str(len(warns)))
    await interaction.response.send_message(embed=e, ephemeral=True)

@tree.command(name="serverinfo", description="מידע על השרת")
async def serverinfo(interaction: discord.Interaction):
    g = interaction.guild
    e = discord.Embed(title=f"🌐 {g.name}", color=discord.Color.blurple())
    if g.icon: e.set_thumbnail(url=g.icon.url)
    e.add_field(name="ID", value=str(g.id))
    e.add_field(name="בעלים", value=str(g.owner))
    e.add_field(name="משתמשים", value=str(g.member_count))
    e.add_field(name="ערוצים", value=str(len(g.channels)))
    e.add_field(name="רולים", value=str(len(g.roles)))
    e.add_field(name="נוצר", value=f"<t:{int(g.created_at.timestamp())}:R>")
    await interaction.response.send_message(embed=e)

@tree.command(name="avatar", description="אווטאר של משתמש")
@app_commands.describe(member="משתמש")
async def avatar(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user
    e = discord.Embed(title=f"🖼️ {member.name}", color=discord.Color.blurple())
    e.set_image(url=member.display_avatar.url)
    await interaction.response.send_message(embed=e)

@tree.command(name="ping", description="פינג הבוט")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 `{round(client.latency * 1000)}ms`")

@tree.command(name="cmd", description="רשימת כל הפקודות")
async def cmd(interaction: discord.Interaction):
    e = discord.Embed(title="📋 כל הפקודות", color=discord.Color.blurple())
    e.add_field(name="🔨 מודרציה", value="/ban /unban /kick /mute /unmute /tempban /softban\n/warn /warnings /clearwarns /clear /purge\n/nick /role /lock /unlock /slowmode /move /vckick", inline=False)
    e.add_field(name="📋 מידע", value="/userinfo /serverinfo /avatar /ping", inline=False)
    e.add_field(name="🎉 כלים", value="/say /embed /poll /giveaway", inline=False)
    e.add_field(name="🤖 אוטומטי", value="ספאם → מיוט 5 דקות + DM\nלינקים → נמחקים + DM\n3 אזהרות → מיוט שעה | 5 → באן", inline=False)
    e.add_field(name="📋 לוגים", value=f"מוד: <#{MOD_LOG_CHANNEL}>\nשרת: <#{SERVER_LOG_CHANNEL}>\nספאם: <#{SPAM_LOG_CHANNEL}>", inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)


client.run(TOKEN)
